<div id="pie" name="pie" style="border: 1px solid blue">
        futuro footer en el pie de la pagina
</div>
<!--Agregando JQUERY,POPPER y luego bootstrap js!-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>

</html>