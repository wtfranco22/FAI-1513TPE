
<div id="lateral" name="lateral" style="height:400px ; width: 10%; float:left; text-align:center; border:1px solid blue">
        Este<br>
        es<br>
        el<br>
        lateral<br>
        izquierdo<br>
</div>