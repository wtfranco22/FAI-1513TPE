<?php
include_once("estructura/cabecera.php");
include_once("estructura/lateral.php");
?>

<div id="cuerpo" name="cuerpo" style="height:400px;border:1px solid blue">
    <?php
    echo "Esta es una aplicación para evaluar mis progresos en la materia PWD 2020.Mi nombre es Franco matias rodriguez y mi Nro de Legajo FAI-1513";
    ?>
</div>

<?php
include_once("estructura/pie.php");
?>