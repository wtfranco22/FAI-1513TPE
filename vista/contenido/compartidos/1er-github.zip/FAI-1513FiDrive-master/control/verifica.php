<?php
echo "Este es un archivo que verificara los datos del index";
?>