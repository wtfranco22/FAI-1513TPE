<?php
echo "Este archivo sera dirigido a la conexion de la base de datos";
?>